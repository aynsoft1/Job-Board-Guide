# Job Board SaaS (PHP + MySQL)

Simple production-style job board example.

## Run
- Setup DB
- Update .env
- Open /public

👉 https://ejobsitesoftware.com
