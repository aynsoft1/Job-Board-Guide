<?php
require_once __DIR__ . '/../Services/JobService.php';

class JobController {

    private $service;

    public function __construct() {
        $this->service = new JobService();
    }

    public function store() {
        $this->service->createJob($_POST);
        echo "Job Created";
    }

    public function index() {
        $jobs = $this->service->getJobs();
        while ($row = $jobs->fetch_assoc()) {
            echo $row['title'] . "<br>";
        }
    }
}
