<?php
class Database {
    private static $conn;

    public static function connect() {
        if (!self::$conn) {
            self::$conn = new mysqli("localhost", "root", "", "jobboard");
        }
        return self::$conn;
    }
}
