<?php
require_once __DIR__ . '/../Controllers/JobController.php';

class Router {
    public static function route($uri) {
        $controller = new JobController();

        if ($uri == '/jobs') {
            $controller->index();
        } elseif ($uri == '/create-job') {
            $controller->store();
        } else {
            echo "404 Not Found";
        }
    }
}
