<?php
class Job {
    public $title;
    public $description;

    public function __construct($data) {
        $this->title = $data['title'];
        $this->description = $data['description'];
    }
}
