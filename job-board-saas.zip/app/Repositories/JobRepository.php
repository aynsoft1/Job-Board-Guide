<?php
require_once __DIR__ . '/../Core/Database.php';

class JobRepository {

    public function create($job) {
        $conn = Database::connect();

        $stmt = $conn->prepare("INSERT INTO jobs (title, description) VALUES (?, ?)");
        $stmt->bind_param("ss", $job->title, $job->description);
        $stmt->execute();

        return $stmt->insert_id;
    }

    public function all() {
        $conn = Database::connect();
        return $conn->query("SELECT * FROM jobs");
    }
}
