<?php
require_once __DIR__ . '/../Repositories/JobRepository.php';
require_once __DIR__ . '/../Models/Job.php';

class JobService {

    private $repo;

    public function __construct() {
        $this->repo = new JobRepository();
    }

    public function createJob($data) {
        $job = new Job($data);
        return $this->repo->create($job);
    }

    public function getJobs() {
        return $this->repo->all();
    }
}
