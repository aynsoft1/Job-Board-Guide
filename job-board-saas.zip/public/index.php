<?php
require_once __DIR__ . '/../app/Core/Router.php';

$uri = $_SERVER['REQUEST_URI'];
Router::route($uri);
