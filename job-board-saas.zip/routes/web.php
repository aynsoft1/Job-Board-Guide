/jobs        -> list jobs
/create-job  -> create job
